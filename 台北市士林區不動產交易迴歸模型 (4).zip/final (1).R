rm(list=ls())
setwd("C:/R-00968108/Final exam")
library(readxl)
h<-read_excel("house.xlsx")
str(h)
h$elevator <- as.numeric(as.character(h$elevator))
install.packages("caTools")
library(caTools)
set.seed(77)
asset.split<-sample.split(h$vacancy , SplitRatio = 0.75)
head(asset.split)
asset.train<- subset(h, asset.split == TRUE)
asset.test<- subset(h, asset.split == FALSE)     
n.train<-nrow(asset.train) ; n.train #訓練資料樣本數
n.test<-nrow(asset.test); n.test 
with(asset.train, pairs(dollar~vacancy+mainbuilding+age+parkingspace+elevator))
m1<-with(asset.train, step(lm(dollar~vacancy+mainbuilding+age+parkingspace+elevator),
                           direction="both")) #逐步迴歸
summary(m1)
summary(m2)
asset.train$vacancy2=sqrt(asset.train$vacancy+0.01)
asset.train$vacancy3=asset.train$vacancy**(1/4)
asset.train$mainbuilding2=asset.train$mainbuilding**(1/8)
asset.train$age2=asset.train$age**(1/8)
asset.train$dollar2=sqrt(asset.train$dollar)
asset.train$type2=(asset.train$type)^4
asset.train$parkingspace2=(asset.train$parkingspace)^2
asset.train$elevator2=(asset.train$elevator)^2
m1<-with(asset.train, step(lm(dollar~vacancy+mainbuilding+age+parkingspace+elevator),
                           direction="both")) #逐步迴歸
m2<-with(asset.train, step(lm(dollar2~vacancy3+mainbuilding2+age2+parkingspace+elevator),
                           direction="both")) #逐步迴歸
m3<-with(asset.train, step(lm(dollar2~vacancy3+mainbuilding2+age2+parkingspace2+elevator+type2),
                           direction="both")) #逐步迴歸
m4=with(asset.train, step(lm(dollar2~vacancy3+mainbuilding2+age2+parkingspace2+elevator2+type2),
                           direction="both")) #逐步迴歸
summary(m4)
resid.m1<-residuals(m2)
qqnorm(resid.m1) 
qqline(resid.m1)
mu<-mean(resid.m1)
sdc<-sd(resid.m1)
hist(resid.m1, breaks=10, prob = TRUE, col="blue")#histogram
curve(dnorm(x, mean=mu, sd=sdc), col="red", lwd=2, add=TRUE, yaxt="n")
#常態性檢定
shapiro.test(resid.m1) #常態性 Shapiro-Wilk normality test
moments::jarque.test(resid.m1)    #JB檢定
ks.test(resid.m1, "pnorm")  #Kolmogorov-Smirnov Test
#隨機性
#統計圖
plot(resid.m1,type = "o", col = "blue") #點線圖
#隨機性檢定
car::durbinWatsonTest(m2) #隨機性
lmtest::dwtest(m1, alternative = "two.sided")#隨機性
plot(fitted(m1),resid.m1)  #fitted values vs. residuals
plot(asset.train$vacancy2, resid.m1)     #x1 vs residuals
plot(asset.train$age, resid.m1)  #x2 vs residuals
plot(asset.train$parkingspace, resid.m1)     #x3 vs residuals
car::ncvTest(lm(dollar2~vacancy3+mainbuilding2+age2+parkingspace+elevator, data=asset.train))#Breusch-Pagan test~x2(1)
 #levene test均質性
car::vif(m1)

hat.m1<-hatvalues(m1)  #leverages
rs.m1<-rstudent(m1)    #studentized residuals
rst.m1<-rstandard(m1)  #Standardized residuals
plot(hat.m1,type = "p", col = "red", ylab="Leverage")  #槓桿量值點圖
abline(h=2*(4/n.train), col="black")  #4個參數的槓桿量值臨界點-2倍average值(h-hat) 
plot(rst.m1, ylab="Standardized residuals") #標準化殘差圖
abline(h=qnorm(0.025),col="red")  #
abline(h=qnorm(1-0.025),col="red")
plot(rs.m1, ylab="Studentized residuals") #t化殘差圖
abline(h=qt(0.025,df=n.train-5),col="red")  #df=n-p-1
abline(h=qt(1-0.025,df=n.train-5),col="red")
car::outlierTest(m1)  # 找出outliers
#outliers 離群值/極端值
cooksd1 <- cooks.distance(m1)  # Cook’s distance
par(mfrow=c(1,1))
plot(cooksd1, pch="*", cex=1, main="Influential Obs by Cooks distance")#plot cook's distance
#Cook's distance < 10% of F(p, n-p)
cutoff<-pf(0.5, 4, n.train-4); cutoff#訂為百分位數> 50%; 1.0; √(p/n)
abline(h = cutoff, col="red")  # add cutoff line
abline(h = sqrt(4/n.train), col="red")  # add cutoff line
#找出cook's dist值大於4*mean(cooksd1)的樣本編號
text(x=1:length(cooksd1)+1, y=cooksd1, labels=ifelse(cooksd1>(4*mean(cooksd1)), names(cooksd1),""), col="red")  # add labels
out1<-as.numeric(names(cooksd1)[(cooksd1 > (4*(mean(cooksd1))))]); out1
olier1<-h[out1, ]; olier1  #擷取離群值資料並存成olier1

#m2
resid.m1<-residuals(m2)
qqnorm(resid.m1) 
qqline(resid.m1)
mu<-mean(resid.m1)
sdc<-sd(resid.m1)
hist(resid.m1, breaks=10, prob = TRUE, col="blue")#histogram
curve(dnorm(x, mean=mu, sd=sdc), col="red", lwd=2, add=TRUE, yaxt="n")
#常態性檢定
shapiro.test(resid.m1) #常態性 Shapiro-Wilk normality test
moments::jarque.test(resid.m1)    #JB檢定
ks.test(resid.m1, "pnorm")  #Kolmogorov-Smirnov Test
#隨機性
#統計圖
plot(resid.m1,type = "o", col = "blue") #點線圖
#隨機性檢定
car::durbinWatsonTest(m1) #隨機性

lmtest::dwtest(m2, alternative = "two.sided")#隨機性
plot(fitted(m2),resid.m1)  #fitted values vs. residuals
plot(asset.train$vacancy3, resid.m1)     #x1 vs residuals
plot(asset.train$mainbuilding2, resid.m1)  #x2 vs residuals
plot(asset.train$age2, resid.m1)     #x3 vs residuals

car::ncvTest(lm(dollar2~vacancy3+mainbuilding2+age2+parkingspace+elevator, data=asset.train))#Breusch-Pagan test~x2(1)
car::vif(m2)
hat.m1<-hatvalues(m2)  #leverages
rs.m1<-rstudent(m2)    #studentized residuals

plot(hat.m1,type = "p", col = "red", ylab="Leverage")  #槓桿量值點圖
abline(h=2*(4/n.train), col="black")  #4個參數的槓桿量值臨界點-2倍average值(h-hat) 
plot(rst.m1, ylab="Standardized residuals") #標準化殘差圖
abline(h=qnorm(0.025),col="red")  #
abline(h=qnorm(1-0.025),col="red")
plot(rs.m1, ylab="Studentized residuals") #t化殘差圖
abline(h=qt(0.025,df=n.train-5),col="red")  #df=n-p-1
abline(h=qt(1-0.025,df=n.train-5),col="red")
car::outlierTest(m2)  # 找出outliers
#outliers 離群值/極端值
cooksd1 <- cooks.distance(m2)  # Cook’s distance
par(mfrow=c(1,1))
plot(cooksd1, pch="*", cex=1, main="Influential Obs by Cooks distance")#plot cook's distance
#Cook's distance < 10% of F(p, n-p)
cutoff<-pf(0.5, 4, n.train-4); cutoff#訂為百分位數> 50%; 1.0; √(p/n)
abline(h = cutoff, col="red")  # add cutoff line
abline(h = sqrt(4/n.train), col="red")  # add cutoff line
#找出cook's dist值大於4*mean(cooksd1)的樣本編號
text(x=1:length(cooksd1)+1, y=cooksd1, labels=ifelse(cooksd1>(4*mean(cooksd1)), names(cooksd1),""), col="red")  # add labels
out1<-as.numeric(names(cooksd1)[(cooksd1 > (4*(mean(cooksd1))))]); out1
olier1<-h[out1, ]; olier1  #擷取離群值資料並存成olier1

ggplot2::qplot(x = vacancy3,
               y = dollar2,
               data = asset.train,
               color = age2)
ggplot2::qplot(x = age2,
               y = dollar2,
               data = asset.train,
               color =elevator)

#m3新增type
resid.m1<-residuals(m3)
qqnorm(resid.m1) 
qqline(resid.m1)
mu<-mean(resid.m1)
sdc<-sd(resid.m1)
hist(resid.m1, breaks=10, prob = TRUE, col="blue")#histogram
curve(dnorm(x, mean=mu, sd=sdc), col="red", lwd=2, add=TRUE, yaxt="n")
#常態性檢定
shapiro.test(resid.m1) #常態性 Shapiro-Wilk normality test
Soments::jarque.test(resid.m1)    #JB檢定
ks.test(resid.m1, "pnorm")  #Kolmogorov-Smirnov Test
#隨機性
#統計圖
plot(resid.m1,type = "o", col = "blue") #點線圖
#隨機性檢定
car::durbinWatsonTest(m3) #隨機性

lmtest::dwtest(m3, alternative = "two.sided")#隨機性
plot(fitted(m3),resid.m1)  #fitted values vs. residuals
plot(asset.train$type2, resid.m1)     #x1 vs residuals
plot(asset.train$mainbuilding2, resid.m1)  #x2 vs residuals
plot(asset.train$age2, resid.m1)     #x3 vs residuals

car::ncvTest(lm(dollar2~vacancy3+mainbuilding2+age2+parkingspace+elevator+type2, data=asset.train))#Breusch-Pagan test~x2(1)
car::vif(m3)
hat.m1<-hatvalues(m3)  #leverages
rs.m1<-rstudent(m3)    #studentized residuals

plot(hat.m1,type = "p", col = "red", ylab="Leverage")  #槓桿量值點圖
abline(h=2*(4/n.train), col="black")  #4個參數的槓桿量值臨界點-2倍average值(h-hat) 
plot(rst.m1, ylab="Standardized residuals") #標準化殘差圖
abline(h=qnorm(0.025),col="red")  #
abline(h=qnorm(1-0.025),col="red")
plot(rs.m1, ylab="Studentized residuals") #t化殘差圖
abline(h=qt(0.025,df=n.train-5),col="red")  #df=n-p-1
abline(h=qt(1-0.025,df=n.train-5),col="red")
car::outlierTest(m3)  # 找出outliers
#outliers 離群值/極端值
cooksd1 <- cooks.distance(m3)  # Cook’s distance
par(mfrow=c(1,1))
plot(cooksd1, pch="*", cex=1, main="Influential Obs by Cooks distance")#plot cook's distance
#Cook's distance < 10% of F(p, n-p)
cutoff<-pf(0.5, 4, n.train-4); cutoff#訂為百分位數> 50%; 1.0; √(p/n)
abline(h = cutoff, col="red")  # add cutoff line
abline(h = sqrt(4/n.train), col="red")  # add cutoff line
#找出cook's dist值大於4*mean(cooksd1)的樣本編號
text(x=1:length(cooksd1)+1, y=cooksd1, labels=ifelse(cooksd1>(4*mean(cooksd1)), names(cooksd1),""), col="red")  # add labels
out1<-as.numeric(names(cooksd1)[(cooksd1 > (4*(mean(cooksd1))))]); out1
olier1<-h[out1, ]; olier1  #擷取離群值資料並存成olier1
predict.test<- predict(m3,data= asset.test)
head(predict.test)
mspr<-(sqrt(asset.test$dollar)-predict.test)^2 #計算平方預測誤差
test.mspr<-sum(mspr)/(n.test);test.mspr#計算均方預測誤差
srow(asset.train)
olsrr::ols_mallows_cp(m2, m2)
olsrr::ols_mallows_cp(m3, m3)
nrow(asset.test) 
AIC(m2,m3)
BIC(m2,m3)
summary(m2)$adj.r.squared
summary(m3)$adj.r.squared   
        